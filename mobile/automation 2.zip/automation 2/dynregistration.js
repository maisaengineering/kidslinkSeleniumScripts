function dynregistration () {
	 dynregistration_login() ;
	 logout();
     window.buttons()["Login Back"].tap();


}