
function loginandlogout () {
  //dynlogin();
    login();
    //addchild();
  logout()

}