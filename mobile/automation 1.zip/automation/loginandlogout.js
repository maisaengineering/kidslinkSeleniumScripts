
function loginandlogout () {
  dynlogin();
  logout()

}