var target = UIATarget.localTarget();
var app = target.frontMostApp();
var window = app.mainWindow();

/**** select your case to test ****/
#import "registration_login.js"
#import "login.js"
#import "login_first.js"
#import "moment.js"
#import "milestone.js"
#import "saysomething.js"
#import "upload_document.js"
#import "view_change_document.js"
#import "editprofile.js"
#import "addchild.js"
#import "inviteparentaccess.js"
#import "invitefriend.js"
#import "changepassword.js"
#import "sharepostfb.js"
#import "logout.js"
#import "loginandlogout.js"
#import "dynlogin.js"



//registration_login();
//login_first();
//login();
//milestone(); 
//moment();
//upload_doc();
view_change_doc();
//editprofile();
//addchild();
//inviteparentaccess()
//invitefriend ()
//changepassword()
//sharepostfb();
//logout();
//dynlogin()
//loginandlogout();

/*********** edit controls **************/


var email_login = ["ios20@test.com", "ios21@test.com"];
var text="";
for(i=0; i<email_login.length; i++) {
    
    //text+=loginandlogout();
}


 