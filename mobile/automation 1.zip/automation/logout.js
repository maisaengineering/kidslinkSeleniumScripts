function logout() {

UIALogger.Start("Logouting app");
target.delay(5);
 
 app.tabBar().buttons()[4].tap();

 target.delay(2); 
 window.tableViews()[0].cells()[5].tap();
UIALogger.Start("Loggged out success");    

}
