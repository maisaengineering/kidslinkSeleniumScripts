function tour() {
    target.delay(2);
window.buttons()[0].tap();
target.delay(2);
window.buttons()[0].tap();
target.delay(2);
window.buttons()[0].tap();
target.delay(2);
window.buttons()[0].tap();
target.delay(2);
window.buttons()[0].tap();
target.delay(2);
window.buttons()[0].tap();
target.delay(2);
window.buttons()[0].tap();
target.delay(2);
window.buttons()[2].tap();
}