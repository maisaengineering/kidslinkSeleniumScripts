require "selenium-webdriver"

#Firefox browser instantiation
driver = Selenium::WebDriver.for :firefox

#Loading the assertselenium URL
driver.navigate.to "http://kl-json.herokuapp.com"

#Typing the UserName
EmailId = driver.find_element(:id, "user_email")
EmailId.send_keys "sas2@test.com"

#Typing the Email-Id
PasswordId = driver.find_element(:id, "user_password")
PasswordId.send_keys "123456"

#Clicking on the Submit Button
sleep(5)
SubmitButton = driver.find_element(:name, "commit")
SubmitButton.click
#
sleep(5)
driver.find_element(:link, "view all").click
#
sleep(5)
driver.find_element(:link, "Household").click
#
sleep(5)
driver.find_element(:link, "Contract").click
#
sleep(5)
driver.find_element(:link, "Household help contract").click
#
########### Document created date enter below link and It will run only more than 1 documents in same category.Otherwise put comment in below link(First Doc).
sleep(5)
driver.find_element(:link, "12/19/2005").click
#########################################        Document view  
												 #sleep(5)
												 #driver.find_element(:link, "View").click

#########################################		 Document edit..........
												 sleep(5)
												 driver.find_element(:link, "Edit").click
#########################################		 Change document type.........								
												sleep(5)
												driver.find_element(:link, "change type").click
#########################################       select document type->household sub category    											
												sleep(10)		
												driver.find_element(:id, "5217606b59a2a5065e00005e").click
												
												
																								
#Company name
sleep(10)
#driver.find_element(:id, "org_provider").clear
#cmpnyId = driver.find_element(:name, "document[org_provider]")
driver.find_element(:xpath, "div.captureAddMetaFields "//input[@id='document_org_provider']");
cmpnyId = driver.find_element(:id, "org_provider")
cmpnyId.send_keys "ghkdfjh gjkfdghkj gbjkfdg fdgkfdjgkd gbjfbkjdf dfgkjbdfk gdfkgbj"



/#Description			
descriptionId = driver.find_element(:id, "document_description")
descriptionId.send_keys "Good One erhiog dfng fgidfng gifdng ngkdfg fdug"/

												
												 
/#########################################		 Delete document     #########################################
			sleep(5)
			driver.find_element(:link, "Delete document").click
########################################		  Click on OK button document will be deleted...
			#sleep(5)
			#driver.switch_to.alert.accept
#########################################        click on cancel button
			sleep(10)
			driver.switch_to.alert.dismiss/

 
 
 
 
 
 
 
 
 
 
 
 
 
 

/#####33details

sleep(5)
cmpnyId = driver.find_element(:id, "document_org_provider").clear
cmpnyId = driver.find_element(:id, "document_org_provider")
cmpnyId.send_keys "maisa solutions"

sleep(5)
descrnId = driver.find_element(:id, "document_description")
descrnId.send_keys "maisa solutions is located in hyderabad"/


















